#include <bits/stdc++.h>

using namespace std;

int n, resp, c;
long long int h, mH, sM=-1;

int main(){
    scanf("%d", &n);

    for(int i=0;i<n;i++){
        scanf("%lld", &h);

        if(h>sM && i!=0){
            sM = h;
            c = 0;
        }
        if(h>=mH){
            mH = h;
            sM = -1;
            c = 0;
            continue;
        }
        if(h==sM)
            c++;

        resp++;
    }

    printf("%d\n", resp-c);

    return 0;
}
