#include <bits/stdc++.h>

using namespace std;

int n, nums[1000001];
long long int d, sum[1000001], resp, c1, c2;
bool g1, g2;

long long int f1(int i, int j){
    if(i-1>=0){
        return sum[j]-sum[i-1];
    }
    return sum[j];
}

long long int f2(int i, int j){
    return f1(0,i) + f1(j,n-1);
}

int main(){
    scanf("%d %lld", &n, &d);

    scanf("%d", &nums[0]);
    sum[0] = nums[0];

    for(int i=1;i<n;i++){
        scanf("%d", &nums[i]);
        sum[i] = sum[i-1] + nums[i];
    }

    for(int i=0;i<n;i++){
        g1 = true;
        g2 = true;

        for(int j=n-1;j>i;j--){
            if(!g1 && !g2)
                break;

            if(g1){
                c1 = f1(i,j);

                if(c1==d){
                    resp++;
                }

                if(c1<d){
                    g1 = false;
                }
            }
            if(g2){
                c2 = f2(i,j);

                if(c2==d){
                    resp++;
                }

                if(c2>d){
                    g2 = false;
                }
            }
        }
    }

    printf("%lld\n", resp);

    return 0;
}
