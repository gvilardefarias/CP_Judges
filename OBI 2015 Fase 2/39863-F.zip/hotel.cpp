#include <bits/stdc++.h>

using namespace std;

int iA, iB, fA, fB, resp=0, a, b, jF[5][5];

pair <pair <int,int>, int> c;
queue <pair <pair <int,int>, int> > bfs;

int main(){
    scanf("%d %d %d %d", &iA, &iB, &fA, &fB);

    bfs.push(make_pair(make_pair(iA, iB), 0));

    while(!bfs.empty()){
        c = bfs.front();
        bfs.pop();
        a = c.first.first;
        b = c.first.second;

        if(a==fA && b==fB){
            resp = c.second;
            break;
        }
        if(jF[a][b])
            continue;

        bfs.push(make_pair(make_pair(!a, b), c.second+1));
        bfs.push(make_pair(make_pair(!a, !b), c.second+1));

        jF[a][b] = 1;
    }

    printf("%d\n", resp);

    return 0;
}
