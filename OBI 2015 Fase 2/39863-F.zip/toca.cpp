#include <bits/stdc++.h>

using namespace std;

int n, m, mapa[1001][1001], visit[1001][1001], i, j, c;

queue <pair <pair <int, int>, int> > bfs;

int main(){
    scanf("%d %d", &n, &m);

    for(i=0;i<n;i++){
        for(j=0;j<m;j++){
            scanf("%d", &mapa[i][j]);

            if(mapa[i][j]==2){
                bfs.push(make_pair(make_pair(i, j), 1));
            }
        }
    }

    while(!bfs.empty()){
        i = bfs.front().first.first;
        j = bfs.front().first.second;
        c = bfs.front().second;
        bfs.pop();

        if(mapa[i][j]==3){
            printf("%d\n", c);
            break;
        }

        if(visit[i][j])
            continue;

        visit[i][j] = 1;

        if(i-1>=0){
            if(mapa[i-1][j])
                bfs.push(make_pair(make_pair(i-1, j), c+1));
        }
        if(i+1<n){
            if(mapa[i+1][j])
                bfs.push(make_pair(make_pair(i+1, j), c+1));
        }
        if(j-1>=0){
            if(mapa[i][j-1])
                bfs.push(make_pair(make_pair(i, j-1), c+1));
        }
        if(j+1<m){
            if(mapa[i][j+1])
                bfs.push(make_pair(make_pair(i, j+1), c+1));
        }
    }

    return 0;
}
