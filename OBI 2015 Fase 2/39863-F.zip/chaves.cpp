#include <bits/stdc++.h>

using namespace std;

int n, tam;
bool resp = true;

stack <int> chaves;

int main(){
    scanf("%d", &n);

    for(int i=0;i<n;i++){
        tam = 0;
        if(!resp)
            break;

        char cod[150]="\0";

        getchar();
        scanf("%[^\n]s", cod);

        tam = strlen(cod);

        for(int j=0;j<tam;j++){
            if(cod[j]=='{'){
                chaves.push(1);
            }
            if(cod[j]=='}'){
                if(chaves.empty()){
                    resp = false;
                    break;
                }

                chaves.pop();
            }
        }
    }

    if(!chaves.empty())
        resp = false;
    if(resp)
        printf("S\n");
    else
        printf("N\n");

    return 0;
}
